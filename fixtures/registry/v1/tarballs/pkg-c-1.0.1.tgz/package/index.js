module.exports = "pkg-c";
