module.exports = "@scope/pkg";
